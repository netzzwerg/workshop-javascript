require(['config','require','../vendor/shim'], function (config, require) {
	require(['../client/client']);
});